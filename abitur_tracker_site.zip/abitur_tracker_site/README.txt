Abi Tracker – deploy-fertige Website

Dateien:
- index.html  -> komplette Website

Schnellster Weg zur echten Safari-URL:
1. Gehe zu Netlify Drop.
2. Entpacke die ZIP-Datei auf deinem Gerät.
3. Ziehe den Ordner "abitur_tracker_site" in die Netlify-Drop-Zone.
4. Danach bekommst du sofort eine öffentliche URL mit netlify.app.
5. Diese URL kannst du direkt in Safari öffnen.

Wichtig:
- Die Website speichert deine Daten lokal im Browser über localStorage.
- Wenn du Safari-Daten löschst oder ein anderes Gerät benutzt, sind die Daten dort nicht automatisch vorhanden.
- Der TradingView-Tab nutzt eine stabile iframe-Einbettung.
- Die Nachrichten-Sektion versucht aktuelle Nachrichten zu laden. Wenn der Browser die Quelle blockiert, zeigt die Seite einfach eine Fehlermeldung statt kaputtzugehen.

Alternativ:
- Du kannst den gleichen Ordner auch auf andere Static-Hosting-Dienste hochladen.
