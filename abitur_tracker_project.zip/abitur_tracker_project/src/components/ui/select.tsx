import * as React from 'react';
import { cn } from '@/lib/utils';

type SelectContextType = {
  value?: string;
  onValueChange?: (value: string) => void;
};

const SelectContext = React.createContext<SelectContextType>({});

export function Select({
  value,
  onValueChange,
  children,
}: {
  value?: string;
  onValueChange?: (value: string) => void;
  children: React.ReactNode;
}) {
  return <SelectContext.Provider value={{ value, onValueChange }}>{children}</SelectContext.Provider>;
}

export function SelectTrigger({ className, children }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('w-full', className)}>{children}</div>;
}

export function SelectValue({ placeholder }: { placeholder?: string }) {
  const { value } = React.useContext(SelectContext);
  return <span>{value || placeholder || ''}</span>;
}

export function SelectContent({ className, children }: React.HTMLAttributes<HTMLSelectElement>) {
  const { value, onValueChange } = React.useContext(SelectContext);
  const options = React.Children.toArray(children).filter(React.isValidElement) as React.ReactElement[];
  return (
    <select
      className={cn(
        'mt-2 h-10 w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-white outline-none focus:border-white/20',
        className,
      )}
      value={value}
      onChange={(e) => onValueChange?.(e.target.value)}
    >
      {options.map((option) => option)}
    </select>
  );
}

export function SelectItem({ value, children }: { value: string; children: React.ReactNode }) {
  return <option value={value}>{children}</option>;
}
