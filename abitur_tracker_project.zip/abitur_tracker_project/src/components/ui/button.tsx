import * as React from 'react';
import { cn } from '@/lib/utils';

type Variant = 'default' | 'outline' | 'ghost';
type Size = 'default' | 'icon';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'default', size = 'default', type = 'button', ...props }, ref) => {
    const variantClass =
      variant === 'outline'
        ? 'border border-white/10 bg-white/5 text-white hover:bg-white/10'
        : variant === 'ghost'
          ? 'bg-transparent text-white hover:bg-white/10'
          : 'bg-white/10 text-white hover:bg-white/20';
    const sizeClass = size === 'icon' ? 'h-10 w-10 p-0' : 'px-4 py-2';

    return (
      <button
        ref={ref}
        type={type}
        className={cn(
          'inline-flex items-center justify-center rounded-xl transition disabled:cursor-not-allowed disabled:opacity-50',
          variantClass,
          sizeClass,
          className,
        )}
        {...props}
      />
    );
  },
);
Button.displayName = 'Button';
