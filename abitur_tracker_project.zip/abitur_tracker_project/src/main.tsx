import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import DailyTrackerWebsite from './index';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <DailyTrackerWebsite />
  </React.StrictMode>
);
