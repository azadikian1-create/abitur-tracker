import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import { createClient, type RealtimeChannel, type User } from "@supabase/supabase-js";
import {
  BarChart3,
  CalendarDays,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  Flame,
  GraduationCap,
  Loader2,
  LogOut,
  Mail,
  Newspaper,
  Plus,
  RefreshCw,
  Timer,
  Trash2,
  Wifi,
  WifiOff,
  Zap,
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

declare global {
  interface Window {
    __APP_ENV__?: Record<string, string | undefined>;
  }
}

const STORAGE_KEY = "abitur-tracker-v9";
const NEWS_ENDPOINTS = [
  "https://www.tagesschau.de/api2u/homepage/",
  "https://www.tagesschau.de/api2/homepage/",
];

const runtimeEnv: Record<string, string | undefined> =
  typeof window !== "undefined" ? window.__APP_ENV__ ?? {} : {};
const viteEnv: Record<string, string | undefined> =
  typeof import.meta !== "undefined" && (import.meta as any)?.env
    ? ((import.meta as any).env as Record<string, string | undefined>)
    : {};

const SUPABASE_URL = runtimeEnv.VITE_SUPABASE_URL ?? viteEnv.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = runtimeEnv.VITE_SUPABASE_ANON_KEY ?? viteEnv.VITE_SUPABASE_ANON_KEY;
const SUPABASE_CONFIGURED = Boolean(SUPABASE_URL && SUPABASE_ANON_KEY);

const supabase = SUPABASE_CONFIGURED
  ? createClient(SUPABASE_URL as string, SUPABASE_ANON_KEY as string, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
      },
    })
  : null;

type Subject = {
  id: string;
  name: string;
  examDate: string;
  type: string;
  targetBlocks: number;
  weeklyTarget: number;
  minutesPerBlock: number;
  accent: string;
};

type PlannedBlock = {
  id: string;
  subjectId: string;
  title: string;
  minutes: number;
  done: boolean;
};

type QuickLog = {
  id: string;
  subjectId: string;
  minutes: number;
  createdAt: string;
};

type DayEntry = {
  priorities: string[];
  completedToday: PlannedBlock[];
  quickLogs: QuickLog[];
  note: string;
  win: string;
};

type ChartConfig = {
  symbol: string;
  interval: string;
  refreshKey: number;
};

type NewsItem = {
  id: string;
  title: string;
  teaser: string;
  url: string;
  date: string;
};

type AppState = {
  subjects: Subject[];
  daily: Record<string, DayEntry>;
  selectedDateKey: string;
  activeTab: "abi" | "trading";
  chartConfig: ChartConfig;
};

type CloudRow = {
  user_id: string;
  app_state: AppState;
  updated_at: string;
};

const DEFAULT_SUBJECTS: Subject[] = [
  {
    id: "bio",
    name: "Biologie",
    examDate: "2026-04-22",
    type: "Schriftlich",
    targetBlocks: 18,
    weeklyTarget: 5,
    minutesPerBlock: 60,
    accent: "from-emerald-400/30 to-teal-400/10",
  },
  {
    id: "math",
    name: "Mathematik",
    examDate: "2026-05-06",
    type: "Schriftlich",
    targetBlocks: 22,
    weeklyTarget: 6,
    minutesPerBlock: 60,
    accent: "from-sky-400/30 to-blue-400/10",
  },
  {
    id: "ethics",
    name: "Ethik",
    examDate: "",
    type: "Schriftlich",
    targetBlocks: 14,
    weeklyTarget: 3,
    minutesPerBlock: 60,
    accent: "from-violet-400/30 to-fuchsia-400/10",
  },
  {
    id: "deutsch",
    name: "Deutsch",
    examDate: "",
    type: "Mündlich",
    targetBlocks: 8,
    weeklyTarget: 2,
    minutesPerBlock: 60,
    accent: "from-amber-400/30 to-orange-400/10",
  },
  {
    id: "english",
    name: "Englisch",
    examDate: "",
    type: "Mündlich",
    targetBlocks: 7,
    weeklyTarget: 1,
    minutesPerBlock: 60,
    accent: "from-pink-400/30 to-rose-400/10",
  },
];

const STARTER_BLOCKS = [
  { subjectId: "bio", title: "Biologie: aktives Wiederholen / Abfrage", minutes: 90 },
  { subjectId: "math", title: "Mathematik: Aufgabenblock", minutes: 120 },
  { subjectId: "ethics", title: "Ethik: Theorie + Beispiel", minutes: 60 },
] as const;

const MOTIVATIONAL_LINES = [
  "Ein erledigter Lerneintrag schlägt zehn perfekte Pläne.",
  "Du musst heute nicht alles schaffen. Nur den nächsten wichtigen Schritt.",
  "Konstanz gewinnt das Abi, nicht Chaos auf den letzten Metern.",
  "Mach den ersten Schritt so klein, dass du wirklich anfängst.",
  "Fortschritt ist messbar. Perfektion nicht.",
] as const;

function formatDateKey(date = new Date()): string {
  return date.toISOString().slice(0, 10);
}

function parseDateKey(dateKey: string): Date {
  return new Date(`${dateKey}T12:00:00`);
}

function dateKeyWithOffset(dateKey: string, offset: number): string {
  const date = parseDateKey(dateKey);
  date.setDate(date.getDate() + offset);
  return formatDateKey(date);
}

function formatLongDate(dateKey: string): string {
  return new Intl.DateTimeFormat("de-DE", {
    weekday: "long",
    day: "2-digit",
    month: "long",
    year: "numeric",
  }).format(parseDateKey(dateKey));
}

function formatShortDay(dateKey: string): string {
  return new Intl.DateTimeFormat("de-DE", {
    weekday: "short",
    day: "2-digit",
    month: "2-digit",
  }).format(parseDateKey(dateKey));
}

function formatDateLabel(dateString: string): string {
  if (!dateString) return "Termin eintragen";
  return new Intl.DateTimeFormat("de-DE", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  }).format(new Date(`${dateString}T12:00:00`));
}

function formatTime(dateString: string): string {
  return new Intl.DateTimeFormat("de-DE", {
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(dateString));
}

function formatMinutesReadable(totalMinutes: number): string {
  const minutes = Math.max(0, Math.round(totalMinutes || 0));
  const hours = Math.floor(minutes / 60);
  const rest = minutes % 60;
  if (hours === 0) return `${rest} Min.`;
  if (rest === 0) return `${hours} Std.`;
  return `${hours} Std. ${rest} Min.`;
}

function formatBlockEquivalent(value: number): string {
  return Number(value || 0).toFixed(1).replace(".0", "");
}

function daysUntil(dateString: string): number | null {
  if (!dateString) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const exam = new Date(`${dateString}T00:00:00`);
  return Math.ceil((exam.getTime() - today.getTime()) / 86400000);
}

function getIsoWeekId(date = new Date()): string {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const week = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
  return `${d.getUTCFullYear()}-W${String(week).padStart(2, "0")}`;
}

function subjectName(subjects: Subject[], id: string): string {
  return subjects.find((subject) => subject.id === id)?.name || "Fach";
}

function createStarterBlocks(dateKey: string): PlannedBlock[] {
  return STARTER_BLOCKS.map((block, index) => ({
    id: `${dateKey}-${block.subjectId}-${index}`,
    subjectId: block.subjectId,
    title: block.title,
    minutes: block.minutes,
    done: false,
  }));
}

function createDefaultEntry(dateKey: string): DayEntry {
  return {
    priorities: ["", "", ""],
    completedToday: createStarterBlocks(dateKey),
    quickLogs: [],
    note: "",
    win: "",
  };
}

function createInitialState(todayKey: string): AppState {
  return {
    subjects: DEFAULT_SUBJECTS,
    daily: { [todayKey]: createDefaultEntry(todayKey) },
    selectedDateKey: todayKey,
    activeTab: "abi",
    chartConfig: {
      symbol: "BINANCE:BTCUSDT",
      interval: "60",
      refreshKey: 0,
    },
  };
}

function normalizeNewsPayload(data: any): NewsItem[] {
  const pools = [
    ...(Array.isArray(data?.topnews) ? data.topnews : []),
    ...(Array.isArray(data?.news) ? data.news : []),
    ...(Array.isArray(data?.breakingNews) ? data.breakingNews : []),
    ...(Array.isArray(data?.regional) ? data.regional : []),
  ];

  return pools
    .map((item: any, index: number) => ({
      id:
        item?.id ||
        item?.sophoraId ||
        item?.externalId ||
        item?.shareURL ||
        item?.detailsweb ||
        `${item?.title || "news"}-${index}`,
      title: item?.title || item?.headline || item?.topline || "Ohne Titel",
      teaser:
        item?.firstSentence ||
        item?.teasertext ||
        item?.shorttext ||
        item?.description ||
        item?.topline ||
        "",
      url: item?.shareURL || item?.detailsweb || item?.url || item?.links?.web || "",
      date: item?.date || item?.datetime || item?.timestamp || "",
    }))
    .filter((item: NewsItem) => item.title)
    .filter(
      (item: NewsItem, index: number, array: NewsItem[]) =>
        array.findIndex((candidate) => candidate.id === item.id || candidate.title === item.title) === index
    )
    .slice(0, 6);
}

function sanitizeState(payload: Partial<AppState> | null | undefined, todayKey: string): AppState {
  const base = createInitialState(todayKey);
  if (!payload) return base;
  return {
    subjects: Array.isArray(payload.subjects) && payload.subjects.length > 0 ? payload.subjects : base.subjects,
    daily: payload.daily && typeof payload.daily === "object" ? payload.daily : base.daily,
    selectedDateKey: payload.selectedDateKey || base.selectedDateKey,
    activeTab: payload.activeTab === "trading" ? "trading" : "abi",
    chartConfig: {
      ...base.chartConfig,
      ...(payload.chartConfig || {}),
    },
  };
}

function safeLoad(todayKey: string): AppState | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return sanitizeState(JSON.parse(raw) as Partial<AppState>, todayKey);
  } catch {
    return null;
  }
}

function buildTradingViewEmbedUrl(symbol: string, interval: string, theme = "dark"): string {
  const params = new URLSearchParams({
    symbol,
    interval,
    theme,
    style: "1",
    timezone: "Europe/Berlin",
    locale: "de_DE",
    withdateranges: "1",
    hide_side_toolbar: "0",
    allow_symbol_change: "1",
    saveimage: "1",
    details: "1",
    hotlist: "1",
    calendar: "1",
  });

  return `https://s.tradingview.com/widgetembed/?${params.toString()}`;
}

function TradingViewWidget({
  symbol,
  interval,
  height = 680,
  theme = "dark",
  refreshKey = 0,
}: {
  symbol: string;
  interval: string;
  height?: number;
  theme?: string;
  refreshKey?: number;
}) {
  const src = useMemo(() => buildTradingViewEmbedUrl(symbol, interval, theme), [symbol, interval, theme]);

  return (
    <div
      className="w-full overflow-hidden rounded-[2rem] border border-white/10 bg-slate-950/90"
      style={{ height: `${height}px` }}
    >
      <iframe
        key={`${src}-${refreshKey}`}
        src={src}
        title={`TradingView ${symbol} ${interval}`}
        className="h-full w-full border-0"
        loading="lazy"
      />
    </div>
  );
}

function StatCard({
  title,
  value,
  subValue,
  icon,
  extra,
}: {
  title: string;
  value: string;
  subValue: string;
  icon: React.ReactNode;
  extra?: React.ReactNode;
}) {
  return (
    <Card className="rounded-[2rem] border border-white/10 bg-white/5 shadow-xl backdrop-blur">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="text-sm text-white/65">{title}</div>
            <div className="mt-2 text-lg font-semibold text-white sm:text-xl">{value}</div>
            <div className="mt-1 text-sm text-white/70">{subValue}</div>
            {extra}
          </div>
          <div className="grid h-11 w-11 place-items-center rounded-2xl bg-white/10 text-white">{icon}</div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function DailyTrackerWebsite() {
  const todayKey = formatDateKey();
  const initialState = useMemo(() => safeLoad(todayKey) ?? createInitialState(todayKey), [todayKey]);

  const [activeTab, setActiveTab] = useState<"abi" | "trading">(initialState.activeTab);
  const [systemTodayKey, setSystemTodayKey] = useState(todayKey);
  const [selectedDateKey, setSelectedDateKey] = useState(initialState.selectedDateKey);
  const [subjects, setSubjects] = useState<Subject[]>(initialState.subjects);
  const [daily, setDaily] = useState<Record<string, DayEntry>>(initialState.daily);
  const [newBlock, setNewBlock] = useState({ subjectId: "bio", title: "", minutes: 60 });
  const [quickEntry, setQuickEntry] = useState({ subjectId: "bio", minutes: 35 });
  const [chartConfig, setChartConfig] = useState<ChartConfig>(initialState.chartConfig);
  const [newsItems, setNewsItems] = useState<NewsItem[]>([]);
  const [newsLoading, setNewsLoading] = useState(false);
  const [newsError, setNewsError] = useState("");

  const [user, setUser] = useState<User | null>(null);
  const [authEmail, setAuthEmail] = useState("");
  const [authMessage, setAuthMessage] = useState("");
  const [authError, setAuthError] = useState("");
  const [sendingLoginLink, setSendingLoginLink] = useState(false);
  const [cloudLoading, setCloudLoading] = useState(false);
  const [cloudSaving, setCloudSaving] = useState(false);
  const [cloudReady, setCloudReady] = useState(!SUPABASE_CONFIGURED);
  const [lastSyncedAt, setLastSyncedAt] = useState<string | null>(null);

  const previousTodayKeyRef = useRef(todayKey);
  const realtimeChannelRef = useRef<RealtimeChannel | null>(null);
  const skipNextCloudSaveRef = useRef(false);
  const lastAppliedHashRef = useRef("");

  const serializableState = useMemo<AppState>(
    () => ({
      subjects,
      daily,
      selectedDateKey,
      activeTab,
      chartConfig,
    }),
    [subjects, daily, selectedDateKey, activeTab, chartConfig]
  );

  const stateHash = useMemo(() => JSON.stringify(serializableState), [serializableState]);

  const applyState = useCallback((payload: AppState) => {
    const next = sanitizeState(payload, formatDateKey());
    skipNextCloudSaveRef.current = true;
    setSubjects(next.subjects);
    setDaily(next.daily);
    setSelectedDateKey(next.selectedDateKey);
    setActiveTab(next.activeTab);
    setChartConfig(next.chartConfig);
  }, []);

  useEffect(() => {
    setDaily((prev) => {
      if (prev[selectedDateKey]) return prev;
      return { ...prev, [selectedDateKey]: createDefaultEntry(selectedDateKey) };
    });
  }, [selectedDateKey]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(serializableState));
  }, [serializableState]);

  const stopRealtime = useCallback(() => {
    if (!supabase || !realtimeChannelRef.current) return;
    supabase.removeChannel(realtimeChannelRef.current);
    realtimeChannelRef.current = null;
  }, []);

  const subscribeToCloudState = useCallback(
    (userId: string) => {
      if (!supabase) return;
      stopRealtime();

      const channel = supabase
        .channel(`user-app-state-${userId}`)
        .on(
          "postgres_changes",
          {
            event: "*",
            schema: "public",
            table: "user_app_state",
            filter: `user_id=eq.${userId}`,
          },
          (payload) => {
            const nextState = (payload.new as CloudRow | undefined)?.app_state;
            if (!nextState) return;
            const nextHash = JSON.stringify(nextState);
            if (nextHash === lastAppliedHashRef.current) return;
            lastAppliedHashRef.current = nextHash;
            applyState(nextState);
            setLastSyncedAt(new Date().toISOString());
          }
        )
        .subscribe();

      realtimeChannelRef.current = channel;
    },
    [applyState, stopRealtime]
  );

  const loadCloudState = useCallback(
    async (userId: string) => {
      if (!supabase) return;
      setCloudLoading(true);
      setAuthError("");

      try {
        const { data, error } = await supabase
          .from("user_app_state")
          .select("user_id, app_state, updated_at")
          .eq("user_id", userId)
          .maybeSingle();

        if (error) throw error;

        const row = data as CloudRow | null;
        if (row?.app_state) {
          const sanitized = sanitizeState(row.app_state, formatDateKey());
          lastAppliedHashRef.current = JSON.stringify(sanitized);
          applyState(sanitized);
          setLastSyncedAt(row.updated_at || new Date().toISOString());
        } else {
          setLastSyncedAt(null);
        }

        subscribeToCloudState(userId);
      } catch (error: any) {
        setAuthError(error?.message || "Cloud-Daten konnten nicht geladen werden.");
      } finally {
        setCloudLoading(false);
        setCloudReady(true);
      }
    },
    [applyState, subscribeToCloudState]
  );

  const saveCloudState = useCallback(async (payload: AppState, userId: string) => {
    if (!supabase) return;
    setCloudSaving(true);
    setAuthError("");

    try {
      const sanitized = sanitizeState(payload, formatDateKey());
      const nextHash = JSON.stringify(sanitized);
      lastAppliedHashRef.current = nextHash;
      const { error } = await supabase.from("user_app_state").upsert(
        {
          user_id: userId,
          app_state: sanitized,
          updated_at: new Date().toISOString(),
        },
        { onConflict: "user_id" }
      );
      if (error) throw error;
      setLastSyncedAt(new Date().toISOString());
    } catch (error: any) {
      setAuthError(error?.message || "Cloud-Daten konnten nicht gespeichert werden.");
    } finally {
      setCloudSaving(false);
    }
  }, []);

  useEffect(() => {
    if (!supabase) return;

    supabase.auth.getSession().then(({ data }) => {
      const nextUser = data.session?.user ?? null;
      setUser(nextUser);
      if (nextUser) {
        void loadCloudState(nextUser.id);
      } else {
        setCloudReady(true);
      }
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      const nextUser = nextSession?.user ?? null;
      setUser(nextUser);
      window.setTimeout(() => {
        if (nextUser) {
          setCloudReady(false);
          void loadCloudState(nextUser.id);
        } else {
          stopRealtime();
          setLastSyncedAt(null);
          setCloudReady(true);
        }
      }, 0);
    });

    return () => {
      subscription.unsubscribe();
      stopRealtime();
    };
  }, [loadCloudState, stopRealtime]);

  useEffect(() => {
    const intervalId = window.setInterval(() => {
      const nextTodayKey = formatDateKey();
      const previousTodayKey = previousTodayKeyRef.current;
      if (nextTodayKey !== previousTodayKey) {
        if (selectedDateKey === previousTodayKey) {
          setSelectedDateKey(nextTodayKey);
        }
        setSystemTodayKey(nextTodayKey);
        previousTodayKeyRef.current = nextTodayKey;
      }
    }, 60000);

    return () => window.clearInterval(intervalId);
  }, [selectedDateKey]);

  useEffect(() => {
    if (!SUPABASE_CONFIGURED || !user || !cloudReady) return;
    if (skipNextCloudSaveRef.current) {
      skipNextCloudSaveRef.current = false;
      return;
    }

    const timeoutId = window.setTimeout(() => {
      void saveCloudState(serializableState, user.id);
    }, 700);

    return () => window.clearTimeout(timeoutId);
  }, [stateHash, user, cloudReady, saveCloudState, serializableState]);

  const loadNews = useCallback(async () => {
    setNewsLoading(true);
    setNewsError("");

    for (const endpoint of NEWS_ENDPOINTS) {
      try {
        const response = await fetch(endpoint, { cache: "no-store" });
        if (!response.ok) throw new Error("response not ok");
        const payload = await response.json();
        const normalized = normalizeNewsPayload(payload);
        if (normalized.length > 0) {
          setNewsItems(normalized);
          setNewsLoading(false);
          return;
        }
      } catch {
        // try next endpoint
      }
    }

    setNewsItems([]);
    setNewsError("Nachrichten konnten gerade nicht geladen werden.");
    setNewsLoading(false);
  }, []);

  useEffect(() => {
    void loadNews();
  }, [loadNews]);

  const sendMagicLink = async () => {
    if (!supabase || !authEmail.trim()) return;
    setSendingLoginLink(true);
    setAuthError("");
    setAuthMessage("");

    const { error } = await supabase.auth.signInWithOtp({
      email: authEmail.trim(),
      options: {
        emailRedirectTo: typeof window !== "undefined" ? window.location.href : undefined,
      },
    });

    if (error) {
      setAuthError(error.message);
    } else {
      setAuthMessage("Link gesendet. Öffne die Mail auf diesem oder einem anderen Gerät und melde dich damit an.");
    }

    setSendingLoginLink(false);
  };

  const signOut = async () => {
    if (!supabase) return;
    setAuthError("");
    setAuthMessage("");
    await supabase.auth.signOut();
  };

  const entry = daily[selectedDateKey] || createDefaultEntry(selectedDateKey);

  const setEntry = (nextEntry: DayEntry) => {
    setDaily((prev) => ({ ...prev, [selectedDateKey]: nextEntry }));
  };

  const selectedWeekId = getIsoWeekId(parseDateKey(selectedDateKey));

  const subjectMetrics = useMemo(() => {
    const metrics = Object.fromEntries(
      subjects.map((subject) => [
        subject.id,
        { totalMinutes: 0, totalBlocksEq: 0, weekMinutes: 0, weekBlocksEq: 0 },
      ])
    ) as Record<string, { totalMinutes: number; totalBlocksEq: number; weekMinutes: number; weekBlocksEq: number }>;

    Object.entries(daily).forEach(([dateKey, dayEntry]) => {
      const isSelectedWeek = getIsoWeekId(parseDateKey(dateKey)) === selectedWeekId;

      dayEntry.completedToday.forEach((block) => {
        if (!block.done || !metrics[block.subjectId]) return;
        metrics[block.subjectId].totalMinutes += block.minutes;
        if (isSelectedWeek) metrics[block.subjectId].weekMinutes += block.minutes;
      });

      dayEntry.quickLogs.forEach((log) => {
        if (!metrics[log.subjectId]) return;
        metrics[log.subjectId].totalMinutes += log.minutes;
        if (isSelectedWeek) metrics[log.subjectId].weekMinutes += log.minutes;
      });
    });

    subjects.forEach((subject) => {
      metrics[subject.id].totalBlocksEq = metrics[subject.id].totalMinutes / Math.max(subject.minutesPerBlock || 60, 1);
      metrics[subject.id].weekBlocksEq = metrics[subject.id].weekMinutes / Math.max(subject.minutesPerBlock || 60, 1);
    });

    return metrics;
  }, [daily, selectedWeekId, subjects]);

  const totalBlocksTarget = subjects.reduce((sum, subject) => sum + subject.targetBlocks, 0);
  const totalBlocksDone = subjects.reduce((sum, subject) => sum + subjectMetrics[subject.id].totalBlocksEq, 0);
  const totalProgress = totalBlocksTarget > 0 ? Math.min(100, Math.round((totalBlocksDone / totalBlocksTarget) * 100)) : 0;

  const completedManualBlocks = entry.completedToday.filter((block) => block.done).length;
  const quickLogCount = entry.quickLogs.length;
  const totalEntriesToday = completedManualBlocks + quickLogCount;
  const todayMinutesDone =
    entry.completedToday.filter((block) => block.done).reduce((sum, block) => sum + block.minutes, 0) +
    entry.quickLogs.reduce((sum, log) => sum + log.minutes, 0);

  const streak = useMemo(() => {
    let count = 0;
    const cursor = new Date();
    while (true) {
      const key = formatDateKey(cursor);
      const current = daily[key];
      if (!current) break;
      const hasManual = current.completedToday.some((block) => block.done);
      const hasQuick = current.quickLogs.length > 0;
      if (!hasManual && !hasQuick) break;
      count += 1;
      cursor.setDate(cursor.getDate() - 1);
    }
    return count;
  }, [daily]);

  const nextExam = useMemo(() => {
    return [...subjects]
      .filter((subject) => subject.examDate)
      .map((subject) => ({ ...subject, remaining: daysUntil(subject.examDate) }))
      .filter((subject) => subject.remaining !== null && subject.remaining >= 0)
      .sort((a, b) => (a.remaining as number) - (b.remaining as number))[0];
  }, [subjects]);

  const weeklySummary = useMemo(() => {
    return subjects.map((subject) => {
      const metric = subjectMetrics[subject.id];
      const progress =
        subject.weeklyTarget > 0 ? Math.min(100, Math.round((metric.weekBlocksEq / subject.weeklyTarget) * 100)) : 0;
      return {
        ...subject,
        weekBlocksEq: metric.weekBlocksEq,
        weekMinutes: metric.weekMinutes,
        progress,
      };
    });
  }, [subjectMetrics, subjects]);

  const recentDays = useMemo(() => {
    return Array.from({ length: 7 }, (_, index) => {
      const dateKey = dateKeyWithOffset(systemTodayKey, index - 6);
      const current = daily[dateKey];
      const doneManual = current?.completedToday.filter((block) => block.done).length || 0;
      const quick = current?.quickLogs.length || 0;
      const minutes =
        (current?.completedToday.filter((block) => block.done).reduce((sum, block) => sum + block.minutes, 0) || 0) +
        (current?.quickLogs.reduce((sum, log) => sum + log.minutes, 0) || 0);

      return {
        key: dateKey,
        label: formatShortDay(dateKey),
        entries: doneManual + quick,
        minutes,
        isSelected: dateKey === selectedDateKey,
        isToday: dateKey === systemTodayKey,
      };
    });
  }, [daily, selectedDateKey, systemTodayKey]);

  const quickAddMinutes = () => {
    const minutes = Number(quickEntry.minutes || 0);
    if (minutes <= 0) return;
    const newLog: QuickLog = {
      id: `${selectedDateKey}-${Date.now()}`,
      subjectId: quickEntry.subjectId,
      minutes,
      createdAt: new Date().toISOString(),
    };
    setEntry({ ...entry, quickLogs: [newLog, ...entry.quickLogs] });
  };

  const line = MOTIVATIONAL_LINES[parseDateKey(systemTodayKey).getDate() % MOTIVATIONAL_LINES.length];
  const selectedDateText = formatLongDate(selectedDateKey);
  const isSelectedToday = selectedDateKey === systemTodayKey;

  const tabButtonClass = (tab: "abi" | "trading") =>
    `rounded-2xl px-4 py-2 text-sm font-medium transition ${
      activeTab === tab
        ? "bg-white text-slate-950"
        : "border border-white/10 bg-white/5 text-white hover:bg-white/10"
    }`;

  const syncStatusLabel = !SUPABASE_CONFIGURED
    ? "Supabase nicht verbunden"
    : !user
      ? "Nicht eingeloggt"
      : cloudLoading
        ? "Cloud wird geladen"
        : cloudSaving
          ? "Speichert gerade"
          : "Cloud-Sync aktiv";

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,_rgba(56,189,248,0.15),_transparent_20%),radial-gradient(circle_at_right,_rgba(168,85,247,0.16),_transparent_22%),linear-gradient(180deg,#020617,#0f172a,#111827)] text-white">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35 }}
          className="mb-8 flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between"
        >
          <div>
            <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3 py-1 text-sm text-white">
              <GraduationCap className="h-4 w-4" />
              Abitur Tracking Dashboard
            </div>
            <h1 className="text-3xl font-bold tracking-tight sm:text-5xl">Dein Abi. Dein System.</h1>
            <p className="mt-3 max-w-3xl text-sm leading-6 text-white/80 sm:text-base">
              Trage Lernzeit direkt ein, tracke deinen Fortschritt pro Fach und synchronisiere alles über mehrere Geräte.
            </p>
          </div>
          <div className="rounded-[2rem] border border-white/10 bg-white/5 px-5 py-4 shadow-2xl backdrop-blur">
            <div className="mb-1 text-sm text-white/70">Heute zählt</div>
            <div className="text-lg font-semibold text-white">{line}</div>
          </div>
        </motion.div>

        <Card className="mb-8 rounded-[2rem] border border-white/10 bg-white/5 shadow-2xl backdrop-blur">
          <CardContent className="p-5">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <div className="flex items-center gap-2 text-sm text-white/70">
                  {SUPABASE_CONFIGURED && user ? <Wifi className="h-4 w-4" /> : <WifiOff className="h-4 w-4" />}
                  {syncStatusLabel}
                </div>
                <div className="mt-2 text-lg font-semibold text-white">
                  {user ? `Angemeldet als ${user.email || "Benutzer"}` : "Melde dich an, damit alle Geräte denselben Stand sehen."}
                </div>
                <div className="mt-1 text-sm text-white/70">
                  {lastSyncedAt ? `Letzte Cloud-Sync: ${formatTime(lastSyncedAt)}` : "Noch keine Cloud-Synchronisierung vorhanden."}
                </div>
              </div>

              {SUPABASE_CONFIGURED && user ? (
                <Button
                  variant="outline"
                  className="rounded-2xl border-white/10 bg-white/5 text-white hover:bg-white/10 hover:text-white"
                  onClick={signOut}
                >
                  <LogOut className="mr-2 h-4 w-4" /> Abmelden
                </Button>
              ) : null}
            </div>

            {!SUPABASE_CONFIGURED ? (
              <div className="mt-5 rounded-[2rem] border border-amber-400/20 bg-amber-400/10 p-5 text-sm text-white/85">
                <div className="mb-3 font-semibold text-white">Damit Cloud-Sync funktioniert, setze diese Variablen in deinem Deployment:</div>
                <div className="rounded-2xl border border-white/10 bg-black/20 p-4 font-mono text-xs leading-6 text-white/90">
                  VITE_SUPABASE_URL=deine-supabase-url{`\n`}
                  VITE_SUPABASE_ANON_KEY=dein-supabase-anon-key
                </div>
                <div className="mt-4 font-semibold text-white">SQL für deine Tabelle:</div>
                <pre className="mt-2 overflow-x-auto rounded-2xl border border-white/10 bg-black/20 p-4 text-xs leading-6 text-white/90">
{`create table if not exists public.user_app_state (
  user_id uuid primary key references auth.users(id) on delete cascade,
  app_state jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.user_app_state enable row level security;

create policy "users_select_own_state"
on public.user_app_state
for select
to authenticated
using ((select auth.uid()) = user_id);

create policy "users_insert_own_state"
on public.user_app_state
for insert
to authenticated
with check ((select auth.uid()) = user_id);

create policy "users_update_own_state"
on public.user_app_state
for update
to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);`}
                </pre>
              </div>
            ) : !user ? (
              <div className="mt-5 grid gap-3 rounded-[2rem] border border-white/10 bg-black/20 p-4 lg:grid-cols-[1fr_auto]">
                <Input
                  type="email"
                  value={authEmail}
                  onChange={(e) => setAuthEmail(e.target.value)}
                  placeholder="deine-mail@example.com"
                  className="rounded-2xl border-white/10 bg-white/5 text-white placeholder:text-white/35"
                />
                <Button
                  className="rounded-2xl bg-white/10 text-white hover:bg-white/20"
                  onClick={sendMagicLink}
                  disabled={sendingLoginLink}
                >
                  {sendingLoginLink ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Mail className="mr-2 h-4 w-4" />}
                  Magic Link senden
                </Button>
              </div>
            ) : null}

            {authMessage ? <div className="mt-4 text-sm text-emerald-300">{authMessage}</div> : null}
            {authError ? <div className="mt-4 text-sm text-rose-300">{authError}</div> : null}
          </CardContent>
        </Card>

        <div className="mb-8 flex flex-wrap items-center gap-3">
          <button type="button" className={tabButtonClass("abi")} onClick={() => setActiveTab("abi")}>
            Abi Tracking
          </button>
          <button type="button" className={tabButtonClass("trading")} onClick={() => setActiveTab("trading")}>
            TradingView Live Chart
          </button>
        </div>

        {activeTab === "trading" ? (
          <div className="space-y-6">
            <Card className="rounded-[2rem] border border-white/10 bg-white/5 shadow-2xl backdrop-blur">
              <CardHeader>
                <CardTitle className="text-white">TradingView Tab</CardTitle>
                <CardDescription className="text-white/70">
                  Stabiler Live-Chart direkt im Dashboard. Symbol und Intervall kannst du hier ändern.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-3 rounded-[2rem] border border-white/10 bg-black/20 p-4 lg:grid-cols-[1.2fr_0.8fr_auto_auto]">
                  <Input
                    value={chartConfig.symbol}
                    onChange={(e) => setChartConfig((prev) => ({ ...prev, symbol: e.target.value.toUpperCase() }))}
                    placeholder="z. B. BINANCE:BTCUSDT oder OANDA:EURUSD"
                    className="rounded-2xl border-white/10 bg-white/5 text-white placeholder:text-white/35"
                  />
                  <Select value={chartConfig.interval} onValueChange={(value) => setChartConfig((prev) => ({ ...prev, interval: value }))}>
                    <SelectTrigger className="rounded-2xl border-white/10 bg-white/5 text-white">
                      <SelectValue placeholder="Intervall" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1m</SelectItem>
                      <SelectItem value="5">5m</SelectItem>
                      <SelectItem value="15">15m</SelectItem>
                      <SelectItem value="30">30m</SelectItem>
                      <SelectItem value="60">1h</SelectItem>
                      <SelectItem value="240">4h</SelectItem>
                      <SelectItem value="1D">1D</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button className="rounded-2xl bg-white/10 text-white hover:bg-white/20" onClick={() => setChartConfig((prev) => ({ ...prev, refreshKey: prev.refreshKey + 1 }))}>
                    Neu laden
                  </Button>
                  <a
                    href="https://www.tradingview.com/#signin"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-medium text-white transition hover:bg-white/10"
                  >
                    TradingView öffnen
                  </a>
                </div>

                <div className="mt-5 rounded-[2rem] border border-amber-400/20 bg-amber-400/10 p-4 text-sm text-white/85">
                  Der Chart läuft stabil im Dashboard. Dein Abi-Stand und dein Trading-Tab werden gemeinsam mit derselben Cloud-Session gespeichert.
                </div>
              </CardContent>
            </Card>

            <Card className="rounded-[2rem] border border-white/10 bg-white/5 shadow-2xl backdrop-blur">
              <CardContent className="p-4 sm:p-5">
                <TradingViewWidget
                  symbol={chartConfig.symbol}
                  interval={chartConfig.interval}
                  theme="dark"
                  refreshKey={chartConfig.refreshKey}
                />
              </CardContent>
            </Card>
          </div>
        ) : (
          <>
            <Card className="mb-8 rounded-[2rem] border border-white/10 bg-white/5 shadow-2xl backdrop-blur">
              <CardHeader>
                <CardTitle className="text-white">Tages-Tracking</CardTitle>
                <CardDescription className="text-white/70">
                  Wechsle zwischen Tagen. Für jeden Tag werden deine Daten getrennt gespeichert und mit der Cloud synchronisiert.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-5 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                  <div>
                    <div className="text-sm text-white/60">Aktueller Lerntag</div>
                    <div className="mt-1 text-xl font-semibold text-white">{selectedDateText}</div>
                    <div className="mt-1 text-sm text-white/65">{isSelectedToday ? "Du bearbeitest heute." : "Du betrachtest einen anderen Tag."}</div>
                  </div>

                  <div className="flex flex-wrap items-center gap-3">
                    <Button variant="outline" className="rounded-2xl border-white/10 bg-white/5 text-white hover:bg-white/10 hover:text-white" onClick={() => setSelectedDateKey((prev) => dateKeyWithOffset(prev, -1))}>
                      <ChevronLeft className="mr-2 h-4 w-4" /> Vorheriger Tag
                    </Button>
                    <Input type="date" value={selectedDateKey} onChange={(e) => setSelectedDateKey(e.target.value)} className="w-[190px] rounded-2xl border-white/10 bg-white/5 text-white" />
                    <Button variant="outline" className="rounded-2xl border-white/10 bg-white/5 text-white hover:bg-white/10 hover:text-white" onClick={() => setSelectedDateKey((prev) => dateKeyWithOffset(prev, 1))}>
                      Nächster Tag <ChevronRight className="ml-2 h-4 w-4" />
                    </Button>
                    <Button className="rounded-2xl bg-white/10 text-white hover:bg-white/20" onClick={() => setSelectedDateKey(systemTodayKey)}>
                      Heute
                    </Button>
                  </div>
                </div>

                <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-7">
                  {recentDays.map((day) => (
                    <button
                      key={day.key}
                      type="button"
                      onClick={() => setSelectedDateKey(day.key)}
                      className={`rounded-3xl border px-4 py-4 text-left transition ${day.isSelected ? "border-sky-300/40 bg-sky-400/15" : "border-white/10 bg-black/20 hover:bg-white/10"}`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="text-sm font-medium text-white">{day.label}</div>
                        {day.isToday ? <div className="rounded-full border border-white/10 bg-white/10 px-2 py-0.5 text-[10px] text-white">Heute</div> : null}
                      </div>
                      <div className="mt-3 text-lg font-semibold text-white">{day.entries} Einträge</div>
                      <div className="mt-1 text-sm text-white/65">{day.minutes} Minuten</div>
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <div className="mb-8 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
              <StatCard title="Nächste Prüfung" value={nextExam ? nextExam.name : "Kein Termin"} subValue={nextExam ? `${nextExam.remaining} Tage` : "Datum eintragen"} icon={<CalendarDays className="h-5 w-5" />} />
              <StatCard title="Gesamtfortschritt" value={`${formatBlockEquivalent(totalBlocksDone)} / ${totalBlocksTarget} Blöcke`} subValue={`${totalProgress}% erledigt`} icon={<BarChart3 className="h-5 w-5" />} extra={<Progress value={totalProgress} className="mt-3 h-2 bg-white/10" />} />
              <StatCard title={isSelectedToday ? "Heute erfasst" : "An diesem Tag"} value={`${totalEntriesToday} Einträge`} subValue={formatMinutesReadable(todayMinutesDone)} icon={<CheckCircle2 className="h-5 w-5" />} />
              <StatCard title="Streak" value={`${streak} Tage`} subValue="mit Lernaktivität" icon={<Flame className="h-5 w-5" />} />
            </div>

            <div className="mb-8 grid gap-6 xl:grid-cols-[0.95fr_1.05fr]">
              <Card className="rounded-[2rem] border border-white/10 bg-white/5 shadow-2xl backdrop-blur">
                <CardHeader>
                  <CardTitle className="text-white">Schneller Zeiteintrag</CardTitle>
                  <CardDescription className="text-white/70">
                    Trage einfach Minuten und Fach ein. Der Fortschritt wird automatisch dem Fach und dem gewählten Tag zugerechnet.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-3 rounded-[2rem] border border-white/10 bg-black/20 p-4 lg:grid-cols-[1fr_0.55fr_auto]">
                    <Select value={quickEntry.subjectId} onValueChange={(value) => setQuickEntry((prev) => ({ ...prev, subjectId: value }))}>
                      <SelectTrigger className="rounded-2xl border-white/10 bg-white/5 text-white">
                        <SelectValue placeholder="Fach wählen" />
                      </SelectTrigger>
                      <SelectContent>
                        {subjects.map((subject) => (
                          <SelectItem key={subject.id} value={subject.id}>{subject.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Input type="number" min={1} max={600} value={quickEntry.minutes} onChange={(e) => setQuickEntry((prev) => ({ ...prev, minutes: Number(e.target.value || 0) }))} className="rounded-2xl border-white/10 bg-white/5 text-white placeholder:text-white/35" />
                    <Button className="rounded-2xl bg-white/10 text-white hover:bg-white/20" onClick={quickAddMinutes}>
                      <Zap className="mr-2 h-4 w-4" /> Sofort eintragen
                    </Button>
                  </div>

                  <div className="mt-5 rounded-[2rem] border border-emerald-400/20 bg-emerald-400/10 p-4 text-sm text-white/85">
                    Beispiel: 35 Minuten + Biologie eintragen. Nach dem Eintragen wird der neue Stand automatisch gespeichert.
                  </div>

                  <div className="mt-5 space-y-3">
                    {entry.quickLogs.length === 0 ? (
                      <div className="rounded-3xl border border-white/10 bg-black/20 px-4 py-5 text-white/70">Noch keine schnellen Zeiteinträge für diesen Tag.</div>
                    ) : (
                      entry.quickLogs.map((log) => (
                        <div key={log.id} className="flex items-center justify-between rounded-3xl border border-white/10 bg-black/20 p-4">
                          <div className="flex items-center gap-3">
                            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-white/10 text-white"><Timer className="h-5 w-5" /></div>
                            <div>
                              <div className="font-semibold text-white">{subjectName(subjects, log.subjectId)}</div>
                              <div className="text-sm text-white/65">{log.minutes} Minuten · {formatTime(log.createdAt)}</div>
                            </div>
                          </div>
                          <Button variant="ghost" size="icon" className="text-white hover:bg-white/10 hover:text-white" onClick={() => setEntry({ ...entry, quickLogs: entry.quickLogs.filter((currentLog) => currentLog.id !== log.id) })}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card className="rounded-[2rem] border border-white/10 bg-white/5 shadow-2xl backdrop-blur">
                <CardHeader>
                  <CardTitle className="text-white">Top-3 für diesen Tag</CardTitle>
                  <CardDescription className="text-white/70">Schreib nur das auf, was an diesem Tag wirklich wichtig ist.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4 lg:grid-cols-3">
                    {entry.priorities.map((item, index) => (
                      <Input
                        key={index}
                        value={item}
                        onChange={(e) => {
                          const next = [...entry.priorities];
                          next[index] = e.target.value;
                          setEntry({ ...entry, priorities: next });
                        }}
                        placeholder={`Priorität ${index + 1}`}
                        className="rounded-2xl border-white/10 bg-white/5 text-white placeholder:text-white/35"
                      />
                    ))}
                  </div>
                  <Textarea value={entry.note} onChange={(e) => setEntry({ ...entry, note: e.target.value })} placeholder="Zum Beispiel: erst Bio anfangen, dann Mathe. Kein Handy im ersten Block." className="min-h-[132px] rounded-3xl border-white/10 bg-white/5 text-white placeholder:text-white/35" />
                </CardContent>
              </Card>
            </div>

            <div className="mb-8 grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
              <Card className="rounded-[2rem] border border-white/10 bg-white/5 shadow-2xl backdrop-blur">
                <CardHeader>
                  <CardTitle className="text-white">Optionale Lernblöcke</CardTitle>
                  <CardDescription className="text-white/70">Falls du mit geplanten Blöcken arbeiten willst, kannst du sie hier abhaken.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {entry.completedToday.map((block) => (
                      <div key={block.id} className={`flex items-center justify-between rounded-3xl border p-4 ${block.done ? "border-emerald-400/30 bg-emerald-400/10" : "border-white/10 bg-white/5"}`}>
                        <button
                          type="button"
                          className="flex flex-1 items-center gap-3 text-left"
                          onClick={() => {
                            const nextBlocks = entry.completedToday.map((currentBlock) =>
                              currentBlock.id === block.id ? { ...currentBlock, done: !currentBlock.done } : currentBlock
                            );
                            setEntry({ ...entry, completedToday: nextBlocks });
                          }}
                        >
                          <div className={`grid h-11 w-11 place-items-center rounded-2xl ${block.done ? "bg-emerald-400/20" : "bg-white/10"}`}><CheckCircle2 className="h-5 w-5 text-white" /></div>
                          <div>
                            <div className="font-semibold text-white">{block.title}</div>
                            <div className="text-sm text-white/65">{subjectName(subjects, block.subjectId)} · {block.minutes} Minuten</div>
                          </div>
                        </button>
                        <Button variant="ghost" size="icon" className="text-white hover:bg-white/10 hover:text-white" onClick={() => setEntry({ ...entry, completedToday: entry.completedToday.filter((currentBlock) => currentBlock.id !== block.id) })}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>

                  <div className="mt-5 grid gap-3 rounded-[2rem] border border-white/10 bg-black/20 p-4 lg:grid-cols-[0.9fr_1.3fr_0.5fr_auto]">
                    <Select value={newBlock.subjectId} onValueChange={(value) => setNewBlock((prev) => ({ ...prev, subjectId: value }))}>
                      <SelectTrigger className="rounded-2xl border-white/10 bg-white/5 text-white"><SelectValue placeholder="Fach wählen" /></SelectTrigger>
                      <SelectContent>
                        {subjects.map((subject) => (
                          <SelectItem key={subject.id} value={subject.id}>{subject.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Input value={newBlock.title} onChange={(e) => setNewBlock((prev) => ({ ...prev, title: e.target.value }))} placeholder="Neuer Lernblock" className="rounded-2xl border-white/10 bg-white/5 text-white placeholder:text-white/35" />
                    <Input type="number" min={15} max={240} value={newBlock.minutes} onChange={(e) => setNewBlock((prev) => ({ ...prev, minutes: Number(e.target.value || 0) }))} className="rounded-2xl border-white/10 bg-white/5 text-white placeholder:text-white/35" />
                    <Button
                      className="rounded-2xl bg-white/10 text-white hover:bg-white/20"
                      onClick={() => {
                        const title = newBlock.title.trim() || `${subjectName(subjects, newBlock.subjectId)} Lernblock`;
                        setEntry({
                          ...entry,
                          completedToday: [
                            ...entry.completedToday,
                            {
                              id: `${selectedDateKey}-${Date.now()}`,
                              subjectId: newBlock.subjectId,
                              title,
                              minutes: Number(newBlock.minutes || 60),
                              done: false,
                            },
                          ],
                        });
                        setNewBlock((prev) => ({ ...prev, title: "", minutes: 60 }));
                      }}
                    >
                      <Plus className="mr-2 h-4 w-4" /> Block
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="rounded-[2rem] border border-white/10 bg-white/5 shadow-2xl backdrop-blur">
                <CardHeader>
                  <CardTitle className="text-white">Wochensoll pro Fach</CardTitle>
                  <CardDescription className="text-white/70">Die Woche der ausgewählten Tagesansicht wird automatisch ausgewertet.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {weeklySummary.map((subject) => (
                    <div key={subject.id} className="rounded-3xl border border-white/10 bg-black/20 p-4">
                      <div className="mb-2 flex items-center justify-between gap-3">
                        <div>
                          <div className="font-semibold text-white">{subject.name}</div>
                          <div className="text-sm text-white/65">{formatBlockEquivalent(subject.weekBlocksEq)} / {subject.weeklyTarget} Blöcke · {formatMinutesReadable(subject.weekMinutes)}</div>
                        </div>
                        <div className="text-sm font-medium text-white">{subject.progress}%</div>
                      </div>
                      <Progress value={subject.progress} className="h-2 bg-white/10" />
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            <div className="mb-8 grid gap-6 xl:grid-cols-[1.05fr_0.95fr]">
              <Card className="rounded-[2rem] border border-white/10 bg-white/5 shadow-2xl backdrop-blur">
                <CardHeader className="flex flex-row items-start justify-between gap-4">
                  <div>
                    <CardTitle className="text-white">Wichtigste Nachrichten des Tages</CardTitle>
                    <CardDescription className="text-white/70">Kurzer Überblick für den Tag, direkt im Dashboard.</CardDescription>
                  </div>
                  <Button variant="outline" className="rounded-2xl border-white/10 bg-white/5 text-white hover:bg-white/10 hover:text-white" onClick={() => void loadNews()} disabled={newsLoading}>
                    <RefreshCw className={`mr-2 h-4 w-4 ${newsLoading ? "animate-spin" : ""}`} /> Aktualisieren
                  </Button>
                </CardHeader>
                <CardContent>
                  {newsError ? <div className="rounded-3xl border border-white/10 bg-black/20 px-4 py-5 text-white/75">{newsError}</div> : null}
                  {!newsError && newsItems.length === 0 && newsLoading ? <div className="rounded-3xl border border-white/10 bg-black/20 px-4 py-5 text-white/75">Lade Nachrichten…</div> : null}
                  {!newsError && newsItems.length > 0 ? (
                    <div className="space-y-3">
                      {newsItems.map((item) => (
                        <div key={item.id} className="rounded-3xl border border-white/10 bg-black/20 p-4">
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex items-start gap-3">
                              <div className="mt-1 grid h-10 w-10 place-items-center rounded-2xl bg-white/10 text-white"><Newspaper className="h-5 w-5" /></div>
                              <div>
                                <div className="font-semibold text-white">{item.title}</div>
                                {item.teaser ? <div className="mt-2 text-sm leading-6 text-white/70">{item.teaser}</div> : null}
                              </div>
                            </div>
                            {item.url ? (
                              <a href={item.url} target="_blank" rel="noreferrer" className="rounded-2xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-white transition hover:bg-white/10">
                                <span className="inline-flex items-center gap-2">Link <ExternalLink className="h-4 w-4" /></span>
                              </a>
                            ) : null}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : null}
                </CardContent>
              </Card>

              <Card className="rounded-[2rem] border border-white/10 bg-white/5 shadow-2xl backdrop-blur">
                <CardHeader>
                  <CardTitle className="text-white">Fächer und Prüfungs-Countdown</CardTitle>
                  <CardDescription className="text-white/70">Fortschritt läuft automatisch über erfasste Minuten und erledigte Lernblöcke.</CardDescription>
                </CardHeader>
                <CardContent className="grid gap-5 lg:grid-cols-2 xl:grid-cols-1">
                  {subjects.map((subject) => {
                    const metric = subjectMetrics[subject.id];
                    const percent = subject.targetBlocks > 0 ? Math.min(100, Math.round((metric.totalBlocksEq / subject.targetBlocks) * 100)) : 0;
                    const remaining = daysUntil(subject.examDate);
                    return (
                      <div key={subject.id} className={`rounded-[2rem] border border-white/10 bg-gradient-to-br ${subject.accent} p-[1px]`}>
                        <div className="h-full rounded-[calc(2rem-1px)] bg-slate-950/90 p-5">
                          <div className="mb-4 flex items-start justify-between gap-3">
                            <div>
                              <div className="text-lg font-semibold text-white">{subject.name}</div>
                              <div className="text-sm text-white/60">{subject.type}</div>
                            </div>
                            <div className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-white/85">{remaining === null ? "Kein Termin" : remaining < 0 ? "Vorbei" : `${remaining} Tage`}</div>
                          </div>

                          <div className="space-y-3">
                            <div>
                              <div className="mb-1 text-sm text-white/65">Prüfungstermin</div>
                              <Input type="date" value={subject.examDate} onChange={(e) => setSubjects((prev) => prev.map((current) => current.id === subject.id ? { ...current, examDate: e.target.value } : current))} className="rounded-2xl border-white/10 bg-white/5 text-white" />
                              <div className="mt-1 text-xs text-white/50">{formatDateLabel(subject.examDate)}</div>
                            </div>

                            <div className="grid grid-cols-3 gap-3">
                              <div>
                                <div className="mb-1 text-sm text-white/65">Zielblöcke</div>
                                <Input type="number" min={1} value={subject.targetBlocks} onChange={(e) => setSubjects((prev) => prev.map((current) => current.id === subject.id ? { ...current, targetBlocks: Number(e.target.value || 0) } : current))} className="rounded-2xl border-white/10 bg-white/5 text-white" />
                              </div>
                              <div>
                                <div className="mb-1 text-sm text-white/65">Wochensoll</div>
                                <Input type="number" min={0} value={subject.weeklyTarget} onChange={(e) => setSubjects((prev) => prev.map((current) => current.id === subject.id ? { ...current, weeklyTarget: Number(e.target.value || 0) } : current))} className="rounded-2xl border-white/10 bg-white/5 text-white" />
                              </div>
                              <div>
                                <div className="mb-1 text-sm text-white/65">Min/Block</div>
                                <Input type="number" min={15} value={subject.minutesPerBlock} onChange={(e) => setSubjects((prev) => prev.map((current) => current.id === subject.id ? { ...current, minutesPerBlock: Number(e.target.value || 60) } : current))} className="rounded-2xl border-white/10 bg-white/5 text-white" />
                              </div>
                            </div>

                            <div className="rounded-3xl border border-white/10 bg-black/20 p-4">
                              <div className="mb-2 flex items-center justify-between">
                                <div>
                                  <div className="text-sm text-white/65">Automatischer Fortschritt</div>
                                  <div className="font-semibold text-white">{formatBlockEquivalent(metric.totalBlocksEq)} / {subject.targetBlocks} Blöcke</div>
                                  <div className="mt-1 text-sm text-white/60">{formatMinutesReadable(metric.totalMinutes)} erfasst</div>
                                </div>
                                <div className="text-sm font-medium text-white">{percent}%</div>
                              </div>
                              <Progress value={percent} className="h-2 bg-white/10" />
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-6 xl:grid-cols-[0.95fr_1.05fr]">
              <Card className="rounded-[2rem] border border-white/10 bg-white/5 shadow-2xl backdrop-blur">
                <CardHeader>
                  <CardTitle className="text-white">Tageserfolg</CardTitle>
                  <CardDescription className="text-white/70">Ein Satz reicht. Hauptsache sichtbar.</CardDescription>
                </CardHeader>
                <CardContent>
                  <Textarea value={entry.win} onChange={(e) => setEntry({ ...entry, win: e.target.value })} placeholder="Zum Beispiel: Ich habe heute trotz Müdigkeit direkt 35 Minuten Bio eingetragen und weitergemacht." className="min-h-[150px] rounded-3xl border-white/10 bg-white/5 text-white placeholder:text-white/35" />
                </CardContent>
              </Card>

              <Card className="rounded-[2rem] border border-white/10 bg-white/5 shadow-2xl backdrop-blur">
                <CardHeader>
                  <CardTitle className="text-white">Mini-System für jeden Tag</CardTitle>
                  <CardDescription className="text-white/70">Einfach, klar und wiederholbar.</CardDescription>
                </CardHeader>
                <CardContent className="grid gap-3">
                  {[
                    "1. Minuten direkt nach dem Lernen eintragen.",
                    "2. Mit derselben Mail auf jedem Gerät einloggen.",
                    "3. Dashboard speichert automatisch lokal und in die Cloud.",
                    "4. Wochensoll regelmäßig kontrollieren.",
                    "5. Schwierige Fächer zuerst, leichte später.",
                  ].map((tip) => (
                    <div key={tip} className="flex items-center gap-3 rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-white">
                      <ChevronRight className="h-4 w-4 text-white/80" />
                      <span>{tip}</span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
