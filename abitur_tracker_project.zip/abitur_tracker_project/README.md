# Abitur Tracker

## Lokal starten

```bash
npm install
npm run dev
```

## Deploy auf Cloudflare Pages

Build command:

```bash
npm run build
```

Build output directory:

```bash
dist
```

## Environment Variables

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
